# Kết quả demand trend và kiểm tra overfit

HOLDOUT: **14 ngày fake mới sau dữ liệu cũ**, không dùng huấn luyện hoặc chọn cấu hình. Phạm vi kết luận là dữ liệu giả lập.

Bảng original_full_test_reports chỉ giữ TEST lịch sử; các bảng audit chấm HOLDOUT mới riêng, loại nhãn vượt ranh giới.

## Phạm vi
- Mốc split: {'validation_start': '2026-07-16 09:40:00+07:00', 'test_start': '2026-08-15 09:40:00+07:00', 'holdout_start': '2026-09-11 00:00:00+07:00', 'data_end_exclusive': '2026-09-25 00:00:00+07:00'}
- Nguồn EDA: raw_parquet_before_feature_filter. Metric chính chấm toàn bộ dòng đủ điều kiện.
- TRAIN_ONLY là chính MODELS của notebook hieuchinh.

## Kết quả candidate cuối
- Car H10 TRAIN: 1,648,849 dòng; WMAPE 11.013%; bias -0.077%; MAE 1.059.
- Car H10 VALIDATION: 646,554 dòng; WMAPE 11.356%; bias +0.281%; MAE 1.044.
- Car H10 TEST: 567,283 dòng; WMAPE 11.471%; bias -0.638%; MAE 1.238.
- Car H10 HOLDOUT: 293,493 dòng; WMAPE 11.656%; bias -0.601%; MAE 1.264.
- Car H30 TRAIN: 1,647,008 dòng; WMAPE 10.202%; bias +0.017%; MAE 2.945.
- Car H30 VALIDATION: 645,972 dòng; WMAPE 11.060%; bias +0.390%; MAE 3.052.
- Car H30 TEST: 566,700 dòng; WMAPE 11.278%; bias -0.665%; MAE 3.651.
- Car H30 HOLDOUT: 292,970 dòng; WMAPE 11.388%; bias -0.316%; MAE 3.708.
- Car H60 TRAIN: 1,645,430 dòng; WMAPE 12.579%; bias +0.010%; MAE 7.265.
- Car H60 VALIDATION: 645,279 dòng; WMAPE 13.988%; bias +0.883%; MAE 7.721.
- Car H60 TEST: 566,010 dòng; WMAPE 14.220%; bias -0.746%; MAE 9.210.
- Car H60 HOLDOUT: 292,370 dòng; WMAPE 14.374%; bias -0.255%; MAE 9.371.
- Motorcycle H10 TRAIN: 1,441,586 dòng; WMAPE 10.673%; bias -0.036%; MAE 1.799.
- Motorcycle H10 VALIDATION: 591,105 dòng; WMAPE 11.161%; bias +0.073%; MAE 1.742.
- Motorcycle H10 TEST: 507,116 dòng; WMAPE 11.022%; bias -0.547%; MAE 2.079.
- Motorcycle H10 HOLDOUT: 263,022 dòng; WMAPE 11.056%; bias -0.809%; MAE 2.075.
- Motorcycle H30 TRAIN: 1,439,780 dòng; WMAPE 10.199%; bias +0.001%; MAE 5.161.
- Motorcycle H30 VALIDATION: 590,524 dòng; WMAPE 10.743%; bias -0.022%; MAE 5.033.
- Motorcycle H30 TEST: 506,604 dòng; WMAPE 10.612%; bias -0.423%; MAE 6.007.
- Motorcycle H30 HOLDOUT: 262,368 dòng; WMAPE 10.738%; bias -0.559%; MAE 6.056.
- Motorcycle H60 TRAIN: 1,438,232 dòng; WMAPE 12.192%; bias +0.000%; MAE 12.348.
- Motorcycle H60 VALIDATION: 589,846 dòng; WMAPE 13.641%; bias +0.346%; MAE 12.783.
- Motorcycle H60 TEST: 505,989 dòng; WMAPE 13.423%; bias -0.333%; MAE 15.200.
- Motorcycle H60 HOLDOUT: 261,702 dòng; WMAPE 13.641%; bias -0.650%; MAE 15.415.

## Dấu hiệu cần kiểm tra
- Car H10 TRAIN → VALIDATION: gap +0.344 điểm %; NO_LARGE_GAP_AT_CONFIGURED_THRESHOLD.
- Car H10 TRAIN → TEST: gap +0.459 điểm %; NO_LARGE_GAP_AT_CONFIGURED_THRESHOLD.
- Car H10 TRAIN → HOLDOUT: gap +0.643 điểm %; NO_LARGE_GAP_AT_CONFIGURED_THRESHOLD.
- Car H30 TRAIN → VALIDATION: gap +0.858 điểm %; NO_LARGE_GAP_AT_CONFIGURED_THRESHOLD.
- Car H30 TRAIN → TEST: gap +1.075 điểm %; NO_LARGE_GAP_AT_CONFIGURED_THRESHOLD.
- Car H30 TRAIN → HOLDOUT: gap +1.185 điểm %; NO_LARGE_GAP_AT_CONFIGURED_THRESHOLD.
- Car H60 TRAIN → VALIDATION: gap +1.409 điểm %; NO_LARGE_GAP_AT_CONFIGURED_THRESHOLD.
- Car H60 TRAIN → TEST: gap +1.641 điểm %; NO_LARGE_GAP_AT_CONFIGURED_THRESHOLD.
- Car H60 TRAIN → HOLDOUT: gap +1.795 điểm %; NO_LARGE_GAP_AT_CONFIGURED_THRESHOLD.
- Motorcycle H10 TRAIN → VALIDATION: gap +0.487 điểm %; NO_LARGE_GAP_AT_CONFIGURED_THRESHOLD.
- Motorcycle H10 TRAIN → TEST: gap +0.348 điểm %; NO_LARGE_GAP_AT_CONFIGURED_THRESHOLD.
- Motorcycle H10 TRAIN → HOLDOUT: gap +0.383 điểm %; NO_LARGE_GAP_AT_CONFIGURED_THRESHOLD.
- Motorcycle H30 TRAIN → VALIDATION: gap +0.543 điểm %; NO_LARGE_GAP_AT_CONFIGURED_THRESHOLD.
- Motorcycle H30 TRAIN → TEST: gap +0.413 điểm %; NO_LARGE_GAP_AT_CONFIGURED_THRESHOLD.
- Motorcycle H30 TRAIN → HOLDOUT: gap +0.538 điểm %; NO_LARGE_GAP_AT_CONFIGURED_THRESHOLD.
- Motorcycle H60 TRAIN → VALIDATION: gap +1.448 điểm %; NO_LARGE_GAP_AT_CONFIGURED_THRESHOLD.
- Motorcycle H60 TRAIN → TEST: gap +1.230 điểm %; NO_LARGE_GAP_AT_CONFIGURED_THRESHOLD.
- Motorcycle H60 TRAIN → HOLDOUT: gap +1.448 điểm %; NO_LARGE_GAP_AT_CONFIGURED_THRESHOLD.

## Cách đọc bins
- `error_bins.csv`: tách absolute/percentage, mode, horizon, model_role, split và scope.
- `rows_pct`: tỷ lệ trên dòng đủ điều kiện trong scope; lỗi % luôn loại actual=0 khỏi mẫu số.
- `error_share_all_pct`: đóng góp vào tổng sai số tuyệt đối toàn tập, không phải tỷ lệ số dòng.
- `WMAPE_contribution_all_pp`: phần đóng góp vào WMAPE toàn tập. Scope con không cộng chồng lên all_rows.
- `zero_actual.csv`: dự đoán dương khi actual=0, tỷ lệ và đóng góp lỗi.
- `actual_1_to_3` và `actual_gt30` giúp tránh kết luận từ lỗi % lớn trên demand nhỏ.

## Giới hạn
- HOLDOUT là 14 ngày fake mới cùng cơ chế; chưa chứng minh chất lượng trên dữ liệu thực.
- VAL đã dùng chọn cấu hình nên không là đánh giá độc lập cuối cùng.
- Model chính chỉ fit TRAIN; audit không fit thêm.
- H30/H60 dùng target chồng lấn; tổng nhãn không phải tổng booking duy nhất.
- Coverage lưới tiềm năng không đồng nghĩa missing nếu hex không hoạt động.
- Giờ đầy đủ cần 6 bucket; ngày/nhóm ít hỗ trợ được ghi rõ.
- Bootstrap theo ngày chỉ là khoảng mô tả, không bảo đảm độc lập theo thời gian.
- Các ngưỡng gap chỉ cảnh báo, không là kết luận production readiness.